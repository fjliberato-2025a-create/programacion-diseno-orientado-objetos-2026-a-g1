package service;

import java.util.HashMap;
import java.util.Map;
import model.Producto;

public class Inventario {
    private Map<String, Producto> productos;
    private Map<String, Integer> cantidades;

    public Inventario() {
        productos = new HashMap<>();
        cantidades = new HashMap<>();
    }

    public void agregarProducto(Producto p) {
        if (productos.containsKey(p.getCodigo())) {
            System.out.println("Error: Ya existe producto con código " + p.getCodigo());
            return;
        }
        productos.put(p.getCodigo(), p);
        cantidades.put(p.getCodigo(), 0);
        System.out.println("Producto agregado: " + p);
    }

    public void entrada(String codigo, int cantidad) {
        if (!productos.containsKey(codigo)) {
            System.out.println("Error: No existe producto con código " + codigo);
            return;
        }
        cantidades.put(codigo, cantidades.get(codigo) + cantidad);
        System.out.println("Entrada de " + cantidad + " unidades al producto " + codigo);
    }

    public void salida(String codigo, int cantidad) {
        if (!productos.containsKey(codigo)) {
            System.out.println("Error: No existe producto con código " + codigo);
            return;
        }
        int stockActual = cantidades.get(codigo);
        if (stockActual < cantidad) {
            System.out.println("Error: Stock insuficiente para el producto " + codigo);
            return;
        }
        cantidades.put(codigo, stockActual - cantidad);
        System.out.println("Salida de " + cantidad + " unidades del producto " + codigo);
    }

    public Producto buscar(String codigo) {
        return productos.get(codigo);
    }

    public void listar() {
        System.out.println("\n--- Reporte de Inventario ---");
        for (String codigo : productos.keySet()) {
            Producto p = productos.get(codigo);
            int stock = cantidades.get(codigo);
            System.out.println(p + " | Stock: " + stock);
        }
    }
}
