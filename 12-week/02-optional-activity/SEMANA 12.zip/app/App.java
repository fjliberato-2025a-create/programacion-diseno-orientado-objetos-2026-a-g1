package app;

import model.Producto;
import service.Inventario;

public class App {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        // Agregar productos
        inventario.agregarProducto(new Producto("001", "Laptop", 2500));
        inventario.agregarProducto(new Producto("002", "Mouse", 50));
        inventario.agregarProducto(new Producto("003", "Teclado", 100));
        inventario.agregarProducto(new Producto("004", "Monitor", 800));

        // Intento de producto repetido
        inventario.agregarProducto(new Producto("001", "Tablet", 1200));

        // Movimientos de stock
        inventario.entrada("001", 10);
        inventario.entrada("002", 20);
        inventario.salida("002", 5);
        inventario.salida("003", 2); // stock insuficiente

        // Consultar producto
        System.out.println("\nConsulta: " + inventario.buscar("001"));

        // Reporte final
        inventario.listar();
    }
}
