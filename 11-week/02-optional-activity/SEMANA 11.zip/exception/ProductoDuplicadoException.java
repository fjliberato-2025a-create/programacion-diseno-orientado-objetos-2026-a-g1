package exception;

public class ProductoDuplicadoException extends RuntimeException {
    public ProductoDuplicadoException(String codigo) {
        super("Ya existe producto con código " + codigo);
    }
}
