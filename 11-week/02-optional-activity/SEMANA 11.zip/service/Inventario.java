package service;

import java.util.ArrayList;
import java.util.List;

import model.Producto;
import exception.ProductoDuplicadoException;

public class Inventario {
    private List<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto p) {
        for (Producto prod : productos) {
            if (prod.getCodigo().equals(p.getCodigo())) {
                throw new ProductoDuplicadoException(p.getCodigo());
            }
        }
        productos.add(p);
        System.out.println("Producto agregado: " + p);
    }

    public void listar() {
        System.out.println("\n--- Lista de productos ---");
        for (Producto p : productos) {
            System.out.println(p);
        }
    }
}

