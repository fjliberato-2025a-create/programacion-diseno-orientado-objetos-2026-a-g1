package app;

import model.Producto;
import service.Inventario;
import exception.ProductoDuplicadoException;

public class App {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        try {
            inventario.agregarProducto(new Producto("001", "Laptop", 2500));
            inventario.agregarProducto(new Producto("002", "Mouse", 50));
            inventario.agregarProducto(new Producto("001", "Tablet", 1200)); // Código repetido
        } catch (ProductoDuplicadoException | IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            inventario.agregarProducto(new Producto("003", "Teclado", -100)); // Precio inválido
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        inventario.listar();
    }
}
