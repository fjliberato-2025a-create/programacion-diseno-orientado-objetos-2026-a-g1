package app;

import model.TipoCliente;
import service.CalculadoraTotal;

public class AppRefactor {
    public static void main(String[] args) {
        double subtotal = 500000;
        boolean aplicaIVA = true;
        boolean aplicaDescuento = true;
        TipoCliente tipo = TipoCliente.VIP;

        CalculadoraTotal calc = new CalculadoraTotal();
        double total = calc.calcular(subtotal, aplicaDescuento, aplicaIVA, tipo);

        System.out.println("Total: " + total);
    }
}
