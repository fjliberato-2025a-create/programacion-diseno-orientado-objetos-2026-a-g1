package service;

import model.TipoCliente;

public class CalculadoraTotal {
    // Constantes para eliminar números mágicos
    private static final double DESCUENTO_VIP = 0.20;
    private static final double DESCUENTO_FRECUENTE = 0.10;
    private static final double DESCUENTO_NORMAL = 0.05;
    private static final double IVA = 0.19;

    public double calcular(double subtotal, boolean aplicaDescuento, boolean aplicaIVA, TipoCliente tipo) {
        if (subtotal <= 0) {
            return 0;
        }

        double total = subtotal;

        if (aplicaDescuento) {
            total -= total * obtenerDescuento(tipo);
        }

        if (aplicaIVA) {
            total += total * IVA;
        }

        // Redondeo a 2 decimales
        total = Math.round(total * 100.0) / 100.0;

        return total;
    }

    private double obtenerDescuento(TipoCliente tipo) {
        switch (tipo) {
            case VIP: return DESCUENTO_VIP;
            case FRECUENTE: return DESCUENTO_FRECUENTE;
            default: return DESCUENTO_NORMAL;
        }
    }
}
