// Archivo: App.java
// Paquete opcional: com.corhuila.poo.semana7

class Envio {
    private String codigo;
    private double pesoKg;

    public Envio(String codigo, double pesoKg) {
        if (codigo == null || codigo.isEmpty()) {
            throw new IllegalArgumentException("Código no puede estar vacío");
        }
        if (pesoKg <= 0) {
            throw new IllegalArgumentException("Peso debe ser mayor a 0");
        }
        this.codigo = codigo;
        this.pesoKg = pesoKg;
    }

    public String getCodigo() { return codigo; }
    public double getPesoKg() { return pesoKg; }

    public double calcularCosto() {
        // Base genérica (puede ser 0 o un valor fijo)
        return 0;
    }

    public String resumen() {
        return "Código: " + codigo + ", Peso: " + pesoKg + " kg, Costo: " + calcularCosto();
    }
}

class EnvioEstandar extends Envio {
    public EnvioEstandar(String codigo, double pesoKg) {
        super(codigo, pesoKg);
    }

    @Override
    public double calcularCosto() {
        return 8000 + (getPesoKg() * 2000);
    }

    @Override
    public String resumen() {
        return "Envío Estándar -> " + super.resumen();
    }
}

class EnvioExpress extends Envio {
    public EnvioExpress(String codigo, double pesoKg) {
        super(codigo, pesoKg);
    }

    @Override
    public double calcularCosto() {
        return 15000 + (getPesoKg() * 3500);
    }

    @Override
    public String resumen() {
        return "Envío Express -> " + super.resumen();
    }
}

class EnvioInternacional extends Envio {
    private String paisDestino;

    public EnvioInternacional(String codigo, double pesoKg, String paisDestino) {
        super(codigo, pesoKg);
        if (paisDestino == null || paisDestino.isEmpty()) {
            throw new IllegalArgumentException("País destino no puede estar vacío");
        }
        this.paisDestino = paisDestino;
    }

    @Override
    public double calcularCosto() {
        return 30000 + (getPesoKg() * 6000);
    }

    @Override
    public String resumen() {
        return "Envío Internacional -> " + super.resumen() + ", País: " + paisDestino;
    }
}

public class App {
    public static void main(String[] args) {
        Envio[] envios = {
                new EnvioEstandar("E001", 2.5),
                new EnvioExpress("X002", 1.2),
                new EnvioInternacional("I003", 3.0, "México")
        };

        double total = 0;
        for (Envio e : envios) {
            System.out.println(e.resumen());
            total += e.calcularCosto();
        }

        System.out.println("Costo total de envíos: " + total);
    }
}
