package persistence;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import model.Producto;

public class ArchivoProductos {
    private static final String RUTA = "data/productos.csv";

    public List<Producto> cargar() {
        List<Producto> lista = new ArrayList<>();
        Path rutaArchivo = Paths.get(RUTA);

        if (!Files.exists(rutaArchivo)) {
            System.out.println("Archivo no encontrado, iniciando inventario vacío.");
            return lista;
        }

        try (BufferedReader br = Files.newBufferedReader(rutaArchivo)) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    Producto p = Producto.fromCSV(linea);
                    if (p != null) lista.add(p);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar archivo: " + e.getMessage());
        }
        return lista;
    }

    public void guardar(List<Producto> lista) {
        Path rutaArchivo = Paths.get(RUTA);
        try {
            Files.createDirectories(rutaArchivo.getParent());
            try (BufferedWriter bw = Files.newBufferedWriter(rutaArchivo,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING)) {
                for (Producto p : lista) {
                    bw.write(p.toString());
                    bw.newLine();
                }
            }
            System.out.println("Datos guardados en " + RUTA);
        } catch (IOException e) {
            System.out.println("Error al guardar archivo: " + e.getMessage());
        }
    }
}
