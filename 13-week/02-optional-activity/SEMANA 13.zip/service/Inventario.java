package service;

import java.util.*;
import model.Producto;

public class Inventario {
    private List<Producto> productos;

    public Inventario(List<Producto> productosIniciales) {
        this.productos = new ArrayList<>(productosIniciales);
    }

    public void agregarProducto(Producto p) {
        for (Producto prod : productos) {
            if (prod.getCodigo().equals(p.getCodigo())) {
                System.out.println("Error: Ya existe producto con código " + p.getCodigo());
                return;
            }
        }
        productos.add(p);
        System.out.println("Producto agregado: " + p);
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void listar() {
        System.out.println("\n--- Inventario actual ---");
        for (Producto p : productos) {
            System.out.println(p);
        }
    }
}
