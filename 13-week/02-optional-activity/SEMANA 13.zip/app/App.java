package app;

import model.Producto;
import service.Inventario;
import persistence.ArchivoProductos;
import java.util.List;

public class App {
    public static void main(String[] args) {
        ArchivoProductos archivo = new ArchivoProductos();

        // Cargar productos desde archivo
        List<Producto> lista = archivo.cargar();
        Inventario inventario = new Inventario(lista);

        // Mostrar inventario inicial
        inventario.listar();

        // Agregar un nuevo producto
        inventario.agregarProducto(new Producto("005", "Impresora", 600));

        // Guardar cambios
        archivo.guardar(inventario.getProductos());

        // Mostrar inventario final
        inventario.listar();
    }
}
